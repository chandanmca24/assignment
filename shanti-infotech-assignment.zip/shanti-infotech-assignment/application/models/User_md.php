<?php
class User_md extends CI_Model {
    
    function __construct()
    {
        parent::__construct(); 
    }
    /**
     * 
     * @param array $insertdata
     * @return boolean
     * @throws Exception if any DB error
     */
    public function insertUser($insertdata){
        try{
            if($this->db->insert('users', $insertdata)){
                return $this->db->insert_id();
            }else{
                return false;
            }
        }catch (Exception $e) {
           throw new Exception($e->getMessage()." >> Function : User_md@insertUser ");
        }
    }  

    public function getUserByEmail($email){
        try{
            $this->db->select('user_id, user_name, user_email, user_mobile, user_address, user_password');
            $this->db->from('users');
            $this->db->where('user_email', $email);
            $query = $this->db->get();
            $result = $query->row_array();
            return $result;
        }catch (Exception $e) {
           throw new Exception($e->getMessage()." >> Function : User_md@insertUser ");
        }
    }  
}
