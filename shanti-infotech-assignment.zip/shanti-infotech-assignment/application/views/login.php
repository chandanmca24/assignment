<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php $this->load->view('layouts/header'); ?>
<div class="container">    
        
    <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3"> 
        
        <div class="row">                
            <div class="iconmelon">
              <svg viewBox="0 0 32 32">
                <g filter="">
                  <use xlink:href="#git"></use>
                </g>
              </svg>
            </div>
        </div>
        
        <div class="panel panel-default" >
            <div class="panel-heading">
                <div class="panel-title text-center">Login</div>
            </div>     

            <div class="panel-body" >

                <form name="form" id="loginForm" class="form-horizontal form" enctype="multipart/form-data" method="POST">
                   
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input id="email" type="text" class="form-control" name="email" value="" placeholder="Email">                                        
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input id="password" type="password" class="form-control" name="password" placeholder="Password">
                    </div>                                                                  

                    <div class="form-group">
                        <!-- Button -->
                        <div class="col-sm-12 controls text-center">
                            <button id="loginSubmitBtn" onclick="doLogin()" type="button" href="#" class="btn btn-primary"><i class="glyphicon glyphicon-log-in"></i> Log in</button>                          
                        </div>
                        <p class="text-center">Don't have an account? <a href="<?=base_url('registration');?>">Register Now</a> </p>
                    </div>

                </form>     

            </div>                     
        </div>  
    </div>
</div>
<?php $this->load->view('layouts/bganimate'); ?>
<?php $this->load->view('layouts/footer'); ?>
<script type="text/javascript">
    function doLogin(){
        $("#loginSubmitBtn").attr("disabled", true);
        var regFormObj = $('#loginForm')[0];
        var formData = new FormData(regFormObj);
        $.ajax({
                type: 'POST',
                url: '<?php echo base_url(); ?>',
                dataType: "json",
                data:formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if(response.code == 1000){
                        $.toaster({ priority :'success', title :'Success', message : response.message});
                        window.location.href = "<?php echo base_url(); ?>chat";
                    }else{
                        $.toaster({ priority :'danger', title :'Error', message : response.errors[Object.keys(response.errors)[0]]});
                    }
                    $("#loginSubmitBtn").attr("disabled", false);

                },
                error: function (request, status, error) {
                    console.log(error);
                    $.toaster({ priority :'danger', title :'Error', message : error});
                    $("#loginSubmitBtn").attr("disabled", false);
                }
            });
    }
</script>
