<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php $this->load->view('layouts/header'); ?>
<div class="container">    
        
    <div id="loginbox" class="mainbox col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3"> 
        
        <div class="row">                
            <div class="iconmelon">
              <svg viewBox="0 0 32 32">
                <g filter="">
                  <use xlink:href="#git"></use>
                </g>
              </svg>
            </div>
        </div>
        
        <div class="panel panel-default" >
            <div class="panel-heading">
                <div class="panel-title text-center">Registration</div>
            </div>     

            <div class="panel-body" >

                <form name="regForm" id="regForm" action="javascript:void(0);" class="form form-horizontal" method="POST">
                   
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input id="name" type="text" class="form-control" name="name" value="" placeholder="Full Name">
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                        <input id="email" type="text" class="form-control" name="email" value="" placeholder="Email Address">
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                        <input id="mobile" type="text" class="form-control" name="mobile" value="" placeholder="Mobile Number">
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
                        <input id="address" type="text" class="form-control" name="address" value="" placeholder="Address">
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input id="password" type="password" class="form-control" name="password" placeholder="Password">
                    </div>                                                                  

                    <div class="form-group">
                        <!-- Button -->
                        <div class="col-sm-12 controls text-center">
                            <button id="regSubmitBtn" onclick="doRegistration()" type="button" href="#" class="btn btn-primary ">Register</button>
                        </div>
                        <p class="text-center">Have an account? <a href="<?=base_url();?>">Log In</a> </p>                          
                    </div>

                </form>     

            </div>                     
        </div>  
    </div>
</div>
<?php $this->load->view('layouts/bganimate'); ?>
<?php $this->load->view('layouts/footer'); ?>
<script type="text/javascript">
    function doRegistration(){
        $("#regSubmitBtn").attr("disabled", true);
        var regFormObj = $('#regForm')[0];
        var formData = new FormData(regFormObj);
        $.ajax({
                type: 'POST',
                url: '<?php echo base_url(); ?>registration',
                dataType: "json",
                data:formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    if(response.code == 1000){
                        $.toaster({ priority :'success', title :'Success', message : response.message});
                        window.location.href = "<?php echo base_url(); ?>";
                    }else{
                        $.toaster({ priority :'danger', title :'Error', message : response.errors[Object.keys(response.errors)[0]]});
                    }
                    $("#regSubmitBtn").attr("disabled", false);

                },
                error: function (request, status, error) {
                    console.log(error);
                    $.toaster({ priority :'danger', title :'Error', message : error});
                    $("#regSubmitBtn").attr("disabled", false);
                }
            });
    }
</script>
