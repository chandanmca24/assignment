<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php $this->load->view('layouts/header'); ?>
<div class="container">
<h3 class=" text-center">Logged in As: <?php echo $loggedinuser['user_name']; ?></h3>
<p class=" text-center"><a href="<?php echo base_url('logout'); ?>">Logout</a></p>
<div class="messaging">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            <div class="recent_heading">
              <h4>Users from Google Sheet</h4>
            </div>
          </div>
          <div class="inbox_chat chatuserlist">
          <?php foreach ($users as $key => $value) { ?>
            <div class="chat_list">
              <div class="chat_people">
                <div class="chat_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                <div class="chat_ib">
                  <h5><?php echo $value['username']; ?></h5>
                  <p><?php echo $value['useremail']; ?> | <?php echo $value['usermobile']; ?></p>
                </div>
              </div>
            </div>
          <?php } ?>
          </div>
        </div>
        <div class="mesgs">
          <div class="msg_history">
            <div class="incoming_msg">
              <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="received_msg">
                <div class="received_withd_msg">
                  <p>Test which is a new approach to have all
                    solutions</p>
                  <span class="time_date"> 11:01 AM    |    June 9</span></div>
              </div>
            </div>
            <div class="outgoing_msg">
              <div class="sent_msg">
                <p>Test which is a new approach to have all
                  solutions</p>
                <span class="time_date"> 11:01 AM    |    June 9</span> </div>
            </div>
            <div class="incoming_msg">
              <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="received_msg">
                <div class="received_withd_msg">
                  <p>Test, which is a new approach to have</p>
                  <span class="time_date"> 11:01 AM    |    Yesterday</span></div>
              </div>
            </div>
            <div class="outgoing_msg">
              <div class="sent_msg">
                <p>Apollo University, Delhi, India Test</p>
                <span class="time_date"> 11:01 AM    |    Today</span> </div>
            </div>
            <div class="incoming_msg">
              <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
              <div class="received_msg">
                <div class="received_withd_msg">
                  <p>We work directly with our designers and suppliers,
                    and sell direct to you, which means quality, exclusive
                    products, at a price anyone can afford.</p>
                  <span class="time_date"> 11:01 AM    |    Today</span></div>
              </div>
            </div>
          </div>
          <div class="type_msg">
            <div class="input_msg_write">
              <input type="text" class="write_msg" placeholder="Type a message" />
              <button class="msg_send_btn" type="button"><i class="glyphicon glyphicon-chevron-right" aria-hidden="true"></i></button>
            </div>
          </div>
        </div>
      </div>
      
      
      <p class="text-center top_spac"> Design by <a target="_blank" href="#">Chandan Singh Gadhwal</a></p>
      
    </div>
</div>
<?php $this->load->view('layouts/bganimate'); ?>
<?php $this->load->view('layouts/footer'); ?>
<script type="text/javascript">
    // function doLogin(){
    //     var chatUsersListSelector = $(".chatuserlist");
    //     chatUsersListSelector.html("<p class='text-center'>Loading...</p>");
    //     $.ajax({
    //             type: 'POST',
    //             url: '<?php echo base_url(); ?>chat/getuserfromgooglesheet',
    //             dataType: "json",
    //             processData: false,
    //             contentType: false,
    //             success: function (response) {
    //                 if(response.code == 1000){
    //                     chatUsersListSelector.html("<p class='text-center'>success</p>");
    //                 }else{
    //                     $.toaster({ priority :'danger', title :'Error', message : response.errors[Object.keys(response.errors)[0]]});
    //                 }

    //             },
    //             error: function (request, status, error) {
    //                 console.log(error);
    //                 $.toaster({ priority :'danger', title :'Error', message : error});
    //                 chatUsersListSelector.html("");
    //             }
    //         });
    // }
</script>
