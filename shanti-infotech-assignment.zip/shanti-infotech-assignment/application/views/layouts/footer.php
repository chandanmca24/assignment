<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="<?=base_url('public/assets/js/animate.js');?>"></script>
<script src="<?=base_url('public/assets/js/jquery.toaster.js');?>"></script>
</body>
</html>