<!DOCTYPE html>
<html>
<head>
<title>Shanti Infotech Assignment dd</title>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" type="text/css" href="<?=base_url('public/assets/css/theme.css');?>">
</head>
<body>