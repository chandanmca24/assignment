<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	function __construct() {
        parent::__construct();
        if($this->session->has_userdata('loggedInUser')){
			redirect('/chat'); 
			exit();
		}
        $this->load->model('user_md');
    }

	public function index()
	{
		if($this->input->method() == 'post') {
			$allPostParams = $this->input->post(NULL, TRUE);
			$this->doLogin($allPostParams);
		}
		$this->load->view('login');
	}

	public function registration()
	{
		if($this->input->method() == 'post') {
			$allPostParams = $this->input->post(NULL, TRUE);
			$this->doRegistration($allPostParams);
		}
		$this->load->view('registraton');
	}

	private function doRegistration($allPostParams){
		if($this->validateRegistration()){

			$insertData = [
			    'user_id'       =>  '',
				'user_name' 	=> 	$allPostParams['name'],
				'user_email' 	=> 	$allPostParams['email'],
				'user_mobile' 	=> 	$allPostParams['mobile'],
				'user_address' 	=> 	$allPostParams['address'],
				'user_password' =>  $this->getPasswordHash($allPostParams['password']),
				'created_at'    =>  date("Y-m-d h:m:s", time())
			];
			
			$insertedId = $this->user_md->insertUser($insertData);
			if(!$insertedId){
				$response = [
					'code' => 3000,
					'errors' => [
						'dberror' => "Insert operation faild please try again."
					]
				];
				echo json_encode($response);
				exit();
			}
			unset($insertData['user_password']);
			$insertData['user_id'] = $insertedId;
			$this->googlesheet_lib->saveDataInGoogleSheet($insertData);
			$response = [
				'code' => 1000,
				'message' => 'User successfully registered.'
			];
			echo json_encode($response);
			exit();
		}
	}

	private function doLogin($allPostParams){
		if($this->validateLogin()){
			$email = $allPostParams['email'];
			$password = $allPostParams['password'];
			$userData = $this->user_md->getUserByEmail($email);
			if(!$userData){
				$response = [
					'code' => 3000,
					'errors' => [
						'dberror' => "User not found."
					]
				];
				echo json_encode($response);
				exit();
			}
			$hash = $userData['user_password'];
			if(!$this->is_password_correct($password,$hash)){
				$response = [
					'code' => 3000,
					'errors' => [
						'dberror' => "Incorrect password, Please use correct password."
					]
				];
				echo json_encode($response);
				exit();
			}

			unset($userData['user_password']);
			$this->session->set_userdata('loggedInUser', $userData);
			$response = [
				'code' => 1000,
				'message' => 'User logged in successfully.'
			];
			echo json_encode($response);
			exit();
		}
	}

	private function validateRegistration()
	{
		$this->form_validation->set_rules('name', 'Full Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.user_email]');
        $this->form_validation->set_rules('mobile', 'Mobile Number ', 'trim|required|regex_match[/^[0-9]{10}$/]');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');

        if ($this->form_validation->run() == FALSE)
        {
            $errors = $this->form_validation->error_array();
            $response = [
				'code' => 3000,
				'errors' => $errors
			];
			echo json_encode($response);
			exit();
        }
        else
        {
            return true;
        }
	}

	private function validateLogin()
	{
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE)
        {
            $errors = $this->form_validation->error_array();
            $response = [
				'code' => 3000,
				'errors' => $errors
			];
			echo json_encode($response);
			exit();
        }
        else
        {
            return true;
        }
	}

	private function getPasswordHash($password){
       return password_hash($password, PASSWORD_DEFAULT);
	}

	private function is_password_correct($password,$hash) {
       if (password_verify($password, $hash)) {
            return true;
       } else {
            return false;
       }
    } 
}
