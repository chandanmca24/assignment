<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends CI_Controller {
	protected $isUserLoggedIn;
	protected $loggedInUser;
	function __construct() {
        parent::__construct();

        $this->isUserLoggedIn = $this->session->has_userdata('loggedInUser');
        if(!$this->isUserLoggedIn){
			redirect('/'); 
			exit();
		}

		$this->loggedInUser = $this->session->userdata('loggedInUser');
    }

	public function index()
	{
		$userList = $this->googlesheet_lib->getGoogleSheetData();
		$data = [
			'loggedinuser' => $this->loggedInUser,
			'users' => $userList
		];
		$this->load->view('chat', $data);
	}

	public function logout()
	{
		$this->session->unset_userdata('loggedInUser');
		$this->session->sess_destroy();
        redirect(base_url()); 
		exit();

	}
}
