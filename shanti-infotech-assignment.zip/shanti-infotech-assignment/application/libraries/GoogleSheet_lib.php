<?php
require FCPATH . '/vendor/autoload.php';
putenv('GOOGLE_APPLICATION_CREDENTIALS=' . FCPATH . '/client_secret.json');
use Google\Spreadsheet\ServiceRequestFactory;
use Google\Spreadsheet\DefaultServiceRequest;

$client = new Google_Client;
$client->useApplicationDefaultCredentials();

$client->setApplicationName("assignment");
$client->setScopes(['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']);

if ($client->isAccessTokenExpired()) {
    $client->refreshTokenWithAssertion();
}

$accessToken = $client->fetchAccessTokenWithAssertion()["access_token"];
ServiceRequestFactory::setInstance(
    new DefaultServiceRequest($accessToken)
);

class GoogleSheet_lib {

    Protected $CI;
    Protected $spreadsheet;
    Protected $worksheets;
    Protected $worksheet;
    Protected $listFeed;

    function __construct() {
        $this->CI = & get_instance();
        $this->spreadsheet = (new Google\Spreadsheet\SpreadsheetService)
           ->getSpreadsheetFeed()
           ->getByTitle('assignment');

        // Get the first worksheet (tab)
        $this->worksheets = $this->spreadsheet->getWorksheetFeed()->getEntries();
        $this->worksheet = $this->worksheets[0];
        $this->listFeed = $this->worksheet->getListFeed();
    }
    
    public function getGoogleSheetData(){
        $userList = [];
        foreach ($this->listFeed->getEntries() as $entry) {
           $representative = $entry->getValues();
           $userList[] = $representative;
        }
        return $userList;
    }

    public function saveDataInGoogleSheet($insertData){
        $insertData = $this->removeunderscorefromkey($insertData);
        $isInserted = $this->listFeed->insert($insertData);
    }

    private function removeunderscorefromkey($insertData){
        $newArray = [];
        foreach ($insertData as $key => $value) {
            $newKey = str_replace("_", "", $key);
            $newArray[$newKey] = $value;
        }
        return $newArray;
    }
}
?>
