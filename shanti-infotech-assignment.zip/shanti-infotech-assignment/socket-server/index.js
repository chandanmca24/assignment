
var fs = require( 'fs' );
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
  res.send("Let's start chat");
});

io.on('connection', function(socket){
   socket.on('room', function(room) {
   	console.log('connected'+room);
        socket.join(room);
   });

   socket.on('onMessage', function(msg){
      console.log('onMessage : '+msg);
      var msg = JSON.parse(msg);
    	//socket.broadcast.to(msg.room).emit('onMessageSend', msg.msg);
   }); 
});

http.listen(3000, function(){
  console.log('listening on *:3000');
});  


